# Chapter 13: Searching and Sorting
This program uses Junit code.
## Imara Bhanj
### Binary Search
This program is an iterative version of Binary Search. We get an output of true if the given element exists within the given list. If it does not, we get an output of false. Finally, if we have a null value, we get an exception. 
### Bubble Sort
This program utilises Bubble Sort. The program sorts the list in descending order as opposed to ascending order. When the list is empty, we get an output of an empty list. Finally, if we have a null value, we get an exception. 
### Selection Sort
This program utilises Selection Sort. The program sorts the list in ascending order, on each iteration of the loop it finds the maximum value. When the list is empty, we get an output of an empty list. Finally, if we have a null value, we get an exception. 
### Quick Sort
This program utilises Quick Sort. The program sorts the list in ascending order, it uses a random index to pivot through the list. When the list is empty, we get an output of an empty list. Finally, if we have a null value, we get an exception. 
