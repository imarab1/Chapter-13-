import java.util.*;
public class selection {
	public static void main(String [] args) {
	List<Integer> list = new ArrayList<>(List.of(1, 2, 3, 4, 5));
	int[] nums = {1, 2, 3, 4, 5};
	//selection(Arrays.copyOf(nums,nums.length));
	System.out.println(selectionHi(list));
	}
	//public static void selection(int[]array){
		//List<Integer> hand = new ArrayList<Integer>();
		//for(int x:array){
			//hand.add(x);
		//}
		//for(int i = 0; i < array.length;i++){ // n
			//int max = hand.get(i);
			//for(int j = i; j < array.length;j++){
				//if(hand.get(j) > max){
					//max = hand.get(j);
				//}
			//}
			//int x = hand.indexOf(max);
			//hand.remove(x);
			//hand.add(i, max);
		//}
		//System.out.println(hand);
	//} 
	public static List<Integer> selectionHi(List<Integer> list) throws IllegalArgumentException{
		//return new ArrayList<Integer>(list);
		List<Integer> hand = new ArrayList<Integer>();
		for(int x:list){
			hand.add(x);
		}
		for(int i = 0; i > list.size();i++){ 
			int max = hand.get(i);
			for(int j = i; j < list.size();j++){
				if(hand.get(j) > max){
					max = hand.get(j);
				}
			}
			int x = hand.indexOf(max);
			hand.remove(x);
			hand.add(i, max);
		}
		return new ArrayList<Integer>(hand);
	} 
}
